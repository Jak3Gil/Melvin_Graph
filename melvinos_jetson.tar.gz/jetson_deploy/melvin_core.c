/*
 * melvin_core.c — Minimal Always-On Learning System
 * 
 * Four-step loop:
 *   1) What is happening?      (INPUT)
 *   2) What did I do?          (RECALL LAST OUTPUT)
 *   3) What should happen?     (PREDICT: propagate, observe, update, credit)
 *   4) Do it.                  (OUTPUT)
 * 
 * Everything is bytes. Learning is local. Graph grows/shrinks dynamically.
 * Layers emerge from density without global backprop.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <sys/select.h>
#include <fcntl.h>
#include <errno.h>

/* ========================================================================
 * COMPILE-TIME PARAMETERS (can be overridden via CLI)
 * ======================================================================== */

#define DEFAULT_NODE_CAP        8192
#define DEFAULT_EDGE_CAP        65536
#define DEFAULT_MACRO_CAP       512
#define DEFAULT_DETECTOR_CAP    128

#define TICK_MS                 50
#define FRAME_SIZE              4096
#define RX_RING_SIZE            (FRAME_SIZE * 4)
#define TX_RING_SIZE            (FRAME_SIZE * 4)

#define PRUNE_PERIOD            200
#define LAYER_PERIOD            100
#define SNAPSHOT_PERIOD         2000

#define LAMBDA_DECAY            0.99f   // count decay
#define LAMBDA_E                0.9f    // eligibility trace
#define BETA_BLEND              0.7f    // predictive vs error
#define GAMMA_SLOW              0.8f    // slow weight fraction
#define ETA_FAST                3       // fast weight step
#define DELTA_MAX               4       // max weight change per tick
#define ALPHA_FAST_DECAY        0.95f
#define ALPHA_SLOW_DECAY        0.999f

#define PRUNE_WEIGHT_THRESH     2
#define STALE_THRESH            200
#define NODE_STALE_THRESH       1000

#define CO_FREQ_THRESH          10
#define SIM_THRESH              0.6f
#define DENSITY_THRESH          0.6f
#define LAYER_MIN_SIZE          10

#define EPSILON_START           0.3f
#define EPSILON_DECAY           0.9995f
#define EPSILON_MIN             0.05f

/* ========================================================================
 * DATA STRUCTURES
 * ======================================================================== */

typedef struct {
    uint32_t id;
    uint8_t  a;           // current activation {0,1}
    uint8_t  a_prev;
    uint16_t theta;       // firing threshold
    uint16_t in_deg;
    uint16_t out_deg;
    uint32_t last_tick_seen;
    uint16_t burst;       // short-term spike count
    
    // For pattern signature (last 32 ticks of activation history)
    uint32_t sig_history; // bit vector
    
    // For layer meta-nodes
    uint8_t  is_meta;
    uint32_t cluster_id;
    
    // Prediction support
    int32_t  soma;        // accumulated input
    uint8_t  hat;         // predicted activation
    
    // Statistics for pruning
    uint16_t total_active_ticks;
} Node;

typedef struct {
    uint32_t src;
    uint32_t dst;
    uint8_t  w_fast;
    uint8_t  w_slow;
    int16_t  credit;      // signed, bias = 0
    uint16_t use_count;
    uint16_t stale_ticks;
    
    // For two-timescale learning
    float    eligibility;
    
    // Predictive lift counters (decayed)
    float    C11;         // count src=1, dst_next=1
    float    C10;         // count src=1, dst_next=0
    float    avg_U;       // average usefulness for slow updates
    uint16_t slow_update_countdown;
} Edge;

typedef struct {
    Node   *nodes;
    uint32_t node_count;
    uint32_t node_cap;
    uint32_t *node_free_list;
    uint32_t node_free_count;
    uint32_t next_node_id;
    
    Edge   *edges;
    uint32_t edge_count;
    uint32_t edge_cap;
    uint32_t *edge_free_list;
    uint32_t edge_free_count;
    
    // Adjacency for fast lookup (could be improved with hash)
    // For simplicity, we'll do linear search in this minimal version
} Graph;

typedef struct {
    char     pattern[64];  // byte pattern or token
    uint16_t len;
    uint32_t node_id;      // associated sensory node
    uint8_t  type;         // 0=exact, 1=contains, 2=regex-like
} Detector;

typedef struct {
    uint8_t  bytes[256];
    uint16_t len;
    float    U_fast;
    float    U_slow;
    uint32_t use_count;
    uint32_t last_used_tick;
} Macro;

typedef struct {
    uint8_t *buf;
    uint32_t size;
    uint32_t head;
    uint32_t tail;
    uint32_t count;
} RingBuffer;

typedef struct {
    Detector *detectors;
    uint32_t  detector_count;
    uint32_t  detector_cap;
    
    Macro    *macros;
    uint32_t  macro_count;
    uint32_t  macro_cap;
    
    RingBuffer rx_ring;
    RingBuffer tx_ring;
    
    uint8_t  current_frame[FRAME_SIZE];
    uint16_t current_frame_len;
    
    uint8_t  last_output_frame[FRAME_SIZE];
    uint16_t last_output_frame_len;
    
    float    epsilon;
    uint64_t tick;
    
    // Statistics
    uint32_t edges_created;
    uint32_t edges_pruned;
    uint32_t nodes_created;
    uint32_t nodes_pruned;
    uint32_t layers_created;
    
    float    mean_error;
    uint32_t active_node_count;
    
    // Global baseline for predictive lift
    float    *P1;  // per node
    float    *P0;  // per node
} System;

/* ========================================================================
 * GLOBALS
 * ======================================================================== */

Graph   g_graph;
System  g_sys;

/* ========================================================================
 * RING BUFFER
 * ======================================================================== */

void ring_init(RingBuffer *rb, uint32_t size) {
    rb->buf = calloc(size, 1);
    rb->size = size;
    rb->head = rb->tail = rb->count = 0;
}

void ring_free(RingBuffer *rb) {
    free(rb->buf);
}

uint32_t ring_write(RingBuffer *rb, const uint8_t *data, uint32_t len) {
    uint32_t written = 0;
    for (uint32_t i = 0; i < len && rb->count < rb->size; i++) {
        rb->buf[rb->head] = data[i];
        rb->head = (rb->head + 1) % rb->size;
        rb->count++;
        written++;
    }
    return written;
}

uint32_t ring_read(RingBuffer *rb, uint8_t *data, uint32_t len) {
    uint32_t read = 0;
    for (uint32_t i = 0; i < len && rb->count > 0; i++) {
        data[i] = rb->buf[rb->tail];
        rb->tail = (rb->tail + 1) % rb->size;
        rb->count--;
        read++;
    }
    return read;
}

uint32_t ring_peek(RingBuffer *rb, uint8_t *data, uint32_t len) {
    uint32_t avail = rb->count < len ? rb->count : len;
    uint32_t pos = rb->tail;
    for (uint32_t i = 0; i < avail; i++) {
        data[i] = rb->buf[pos];
        pos = (pos + 1) % rb->size;
    }
    return avail;
}

/* ========================================================================
 * GRAPH MANAGEMENT
 * ======================================================================== */

void graph_init(Graph *g, uint32_t node_cap, uint32_t edge_cap) {
    g->nodes = calloc(node_cap, sizeof(Node));
    g->node_cap = node_cap;
    g->node_count = 0;
    g->node_free_list = calloc(node_cap, sizeof(uint32_t));
    g->node_free_count = 0;
    g->next_node_id = 1;
    
    g->edges = calloc(edge_cap, sizeof(Edge));
    g->edge_cap = edge_cap;
    g->edge_count = 0;
    g->edge_free_list = calloc(edge_cap, sizeof(uint32_t));
    g->edge_free_count = 0;
}

void graph_free(Graph *g) {
    free(g->nodes);
    free(g->node_free_list);
    free(g->edges);
    free(g->edge_free_list);
}

uint32_t node_create(Graph *g) {
    uint32_t idx;
    if (g->node_free_count > 0) {
        idx = g->node_free_list[--g->node_free_count];
    } else {
        if (g->node_count >= g->node_cap) {
            fprintf(stderr, "ERROR: Node capacity exceeded\n");
            return UINT32_MAX;
        }
        idx = g->node_count++;
    }
    
    Node *n = &g->nodes[idx];
    memset(n, 0, sizeof(Node));
    n->id = g->next_node_id++;
    n->theta = 128; // default threshold
    n->last_tick_seen = g_sys.tick;
    
    return idx;
}

void node_delete(Graph *g, uint32_t idx) {
    if (idx >= g->node_count) return;
    g->node_free_list[g->node_free_count++] = idx;
}

uint32_t edge_create(Graph *g, uint32_t src_idx, uint32_t dst_idx) {
    uint32_t idx;
    if (g->edge_free_count > 0) {
        idx = g->edge_free_list[--g->edge_free_count];
    } else {
        if (g->edge_count >= g->edge_cap) {
            fprintf(stderr, "ERROR: Edge capacity exceeded\n");
            return UINT32_MAX;
        }
        idx = g->edge_count++;
    }
    
    Edge *e = &g->edges[idx];
    memset(e, 0, sizeof(Edge));
    e->src = src_idx;
    e->dst = dst_idx;
    e->w_fast = 32;  // small initial weight
    e->w_slow = 32;
    e->slow_update_countdown = 50;
    
    g->nodes[src_idx].out_deg++;
    g->nodes[dst_idx].in_deg++;
    
    g_sys.edges_created++;
    
    return idx;
}

void edge_delete(Graph *g, uint32_t idx) {
    if (idx >= g->edge_count) return;
    Edge *e = &g->edges[idx];
    
    if (e->src < g->node_count) g->nodes[e->src].out_deg--;
    if (e->dst < g->node_count) g->nodes[e->dst].in_deg--;
    
    g->edge_free_list[g->edge_free_count++] = idx;
    g_sys.edges_pruned++;
}

Edge* find_edge(Graph *g, uint32_t src_idx, uint32_t dst_idx) {
    for (uint32_t i = 0; i < g->edge_count; i++) {
        if (g->edge_free_count > 0) {
            // Check if this index is in free list
            int is_free = 0;
            for (uint32_t j = 0; j < g->edge_free_count; j++) {
                if (g->edge_free_list[j] == i) {
                    is_free = 1;
                    break;
                }
            }
            if (is_free) continue;
        }
        
        Edge *e = &g->edges[i];
        if (e->src == src_idx && e->dst == dst_idx) {
            return e;
        }
    }
    return NULL;
}

/* ========================================================================
 * DETECTORS (Byte patterns → Node activations)
 * ======================================================================== */

void detector_init(uint32_t cap) {
    g_sys.detectors = calloc(cap, sizeof(Detector));
    g_sys.detector_cap = cap;
    g_sys.detector_count = 0;
}

uint32_t detector_add(const char *pattern, uint8_t type) {
    if (g_sys.detector_count >= g_sys.detector_cap) return UINT32_MAX;
    
    Detector *d = &g_sys.detectors[g_sys.detector_count++];
    strncpy(d->pattern, pattern, 63);
    d->pattern[63] = 0;
    d->len = strlen(d->pattern);
    d->type = type;
    d->node_id = node_create(&g_graph);
    
    return d->node_id;
}

void detector_run_all(const uint8_t *frame, uint16_t frame_len) {
    for (uint32_t i = 0; i < g_sys.detector_count; i++) {
        Detector *d = &g_sys.detectors[i];
        Node *n = &g_graph.nodes[d->node_id];
        
        n->a_prev = n->a;
        n->a = 0;
        
        if (d->type == 0) {
            // Exact match
            if (frame_len >= d->len) {
                if (memcmp(frame, d->pattern, d->len) == 0) {
                    n->a = 1;
                }
            }
        } else if (d->type == 1) {
            // Contains
            for (uint16_t j = 0; j + d->len <= frame_len; j++) {
                if (memcmp(frame + j, d->pattern, d->len) == 0) {
                    n->a = 1;
                    break;
                }
            }
        }
        
        if (n->a) {
            n->last_tick_seen = g_sys.tick;
            n->burst++;
        } else {
            n->burst = n->burst > 0 ? n->burst - 1 : 0;
        }
        
        // Update signature history
        n->sig_history = (n->sig_history << 1) | n->a;
    }
}

/* ========================================================================
 * MACROS (Action selection)
 * ======================================================================== */

void macro_init(uint32_t cap) {
    g_sys.macros = calloc(cap, sizeof(Macro));
    g_sys.macro_cap = cap;
    g_sys.macro_count = 0;
    g_sys.epsilon = EPSILON_START;
}

uint32_t macro_add(const uint8_t *bytes, uint16_t len) {
    if (g_sys.macro_count >= g_sys.macro_cap) return UINT32_MAX;
    
    Macro *m = &g_sys.macros[g_sys.macro_count++];
    memcpy(m->bytes, bytes, len);
    m->len = len;
    m->U_fast = 0.5f;
    m->U_slow = 0.5f;
    m->use_count = 0;
    m->last_used_tick = 0;
    
    return g_sys.macro_count - 1;
}

void macro_add_defaults() {
    // Safe alphabet
    for (char c = 'a'; c <= 'z'; c++) {
        uint8_t b = (uint8_t)c;
        macro_add(&b, 1);
    }
    for (char c = 'A'; c <= 'Z'; c++) {
        uint8_t b = (uint8_t)c;
        macro_add(&b, 1);
    }
    for (char c = '0'; c <= '9'; c++) {
        uint8_t b = (uint8_t)c;
        macro_add(&b, 1);
    }
    
    // Special chars
    uint8_t newline = '\n';
    macro_add(&newline, 1);
    uint8_t space = ' ';
    macro_add(&space, 1);
    uint8_t dot = '.';
    macro_add(&dot, 1);
    uint8_t slash = '/';
    macro_add(&slash, 1);
}

uint32_t macro_select() {
    // ε-greedy
    float r = (float)rand() / RAND_MAX;
    
    if (r < g_sys.epsilon) {
        // Random
        return rand() % g_sys.macro_count;
    } else {
        // Best utility (blend of fast and slow)
        float best_u = -1e9;
        uint32_t best_idx = 0;
        
        for (uint32_t i = 0; i < g_sys.macro_count; i++) {
            Macro *m = &g_sys.macros[i];
            float u = GAMMA_SLOW * m->U_slow + (1.0f - GAMMA_SLOW) * m->U_fast;
            if (u > best_u) {
                best_u = u;
                best_idx = i;
            }
        }
        
        return best_idx;
    }
}

void macro_update_utility(uint32_t idx, float reward) {
    if (idx >= g_sys.macro_count) return;
    Macro *m = &g_sys.macros[idx];
    
    // Fast track
    m->U_fast = ALPHA_FAST_DECAY * m->U_fast + (1.0f - ALPHA_FAST_DECAY) * reward;
    
    // Slow track (less aggressive)
    m->U_slow = ALPHA_SLOW_DECAY * m->U_slow + (1.0f - ALPHA_SLOW_DECAY) * reward;
    
    m->use_count++;
    m->last_used_tick = g_sys.tick;
}

/* ========================================================================
 * PROPAGATION & PREDICTION
 * ======================================================================== */

void propagate() {
    // Clear soma and predictions
    for (uint32_t i = 0; i < g_graph.node_count; i++) {
        Node *n = &g_graph.nodes[i];
        n->soma = 0;
        n->hat = 0;
    }
    
    // Accumulate weighted inputs
    for (uint32_t i = 0; i < g_graph.edge_count; i++) {
        // Check if edge is free
        int is_free = 0;
        for (uint32_t j = 0; j < g_graph.edge_free_count; j++) {
            if (g_graph.edge_free_list[j] == i) {
                is_free = 1;
                break;
            }
        }
        if (is_free) continue;
        
        Edge *e = &g_graph.edges[i];
        Node *src = &g_graph.nodes[e->src];
        Node *dst = &g_graph.nodes[e->dst];
        
        // Effective weight
        int w_eff = (int)(GAMMA_SLOW * e->w_slow + (1.0f - GAMMA_SLOW) * e->w_fast);
        if (w_eff < 0) w_eff = 0;
        if (w_eff > 255) w_eff = 255;
        
        if (src->a) {
            dst->soma += w_eff;
            e->use_count++;
            e->stale_ticks = 0;
        } else {
            e->stale_ticks++;
        }
    }
    
    // Compute predictions
    g_sys.active_node_count = 0;
    for (uint32_t i = 0; i < g_graph.node_count; i++) {
        Node *n = &g_graph.nodes[i];
        n->hat = (n->soma >= n->theta) ? 1 : 0;
        
        if (n->a) {
            g_sys.active_node_count++;
        }
    }
}

/* ========================================================================
 * OBSERVATION, UPDATE, CREDIT
 * ======================================================================== */

void observe_and_update() {
    float total_error = 0;
    uint32_t error_count = 0;
    
    // Update global baseline counts
    for (uint32_t i = 0; i < g_graph.node_count; i++) {
        Node *n = &g_graph.nodes[i];
        g_sys.P1[i] *= LAMBDA_DECAY;
        g_sys.P0[i] *= LAMBDA_DECAY;
        
        if (n->a) {
            g_sys.P1[i] += 1.0f;
        } else {
            g_sys.P0[i] += 1.0f;
        }
    }
    
    // Per-edge learning
    for (uint32_t i = 0; i < g_graph.edge_count; i++) {
        int is_free = 0;
        for (uint32_t j = 0; j < g_graph.edge_free_count; j++) {
            if (g_graph.edge_free_list[j] == i) {
                is_free = 1;
                break;
            }
        }
        if (is_free) continue;
        
        Edge *e = &g_graph.edges[i];
        Node *src = &g_graph.nodes[e->src];
        Node *dst = &g_graph.nodes[e->dst];
        
        // Observation
        int a_j_next = dst->a;
        int hat_j = dst->hat;
        int surprise = (a_j_next != hat_j) ? 1 : 0;
        
        if (surprise) {
            total_error += 1.0f;
            error_count++;
        }
        
        // Discrepancy
        int d_ij = src->a_prev * (a_j_next - hat_j); // {-1, 0, +1}
        
        // Update predictive lift counters
        e->C11 *= LAMBDA_DECAY;
        e->C10 *= LAMBDA_DECAY;
        
        if (src->a_prev) {
            if (a_j_next) {
                e->C11 += 1.0f;
            } else {
                e->C10 += 1.0f;
            }
        }
        
        // Compute usefulness
        float p_j_given_i = e->C11 / (e->C11 + e->C10 + 1e-6f);
        float p_j = g_sys.P1[e->dst] / (g_sys.P1[e->dst] + g_sys.P0[e->dst] + 1e-6f);
        float u_ij = p_j_given_i - p_j;
        
        float e_ij = d_ij * surprise;
        
        float U_ij = BETA_BLEND * u_ij + (1.0f - BETA_BLEND) * e_ij;
        
        // Update average usefulness for slow track
        e->avg_U = 0.95f * e->avg_U + 0.05f * U_ij;
        
        // Eligibility trace
        e->eligibility = LAMBDA_E * e->eligibility + src->a_prev;
        
        // Fast weight update
        float delta_fast = ETA_FAST * U_ij * e->eligibility;
        if (delta_fast > DELTA_MAX) delta_fast = DELTA_MAX;
        if (delta_fast < -DELTA_MAX) delta_fast = -DELTA_MAX;
        
        int new_w_fast = e->w_fast + (int)delta_fast;
        if (new_w_fast < 0) new_w_fast = 0;
        if (new_w_fast > 255) new_w_fast = 255;
        e->w_fast = new_w_fast;
        
        // Slow weight update (sign-only, occasional)
        e->slow_update_countdown--;
        if (e->slow_update_countdown == 0) {
            e->slow_update_countdown = 50;
            
            int delta_slow = 0;
            if (e->avg_U > 0.05f) delta_slow = 1;
            else if (e->avg_U < -0.05f) delta_slow = -1;
            
            int new_w_slow = e->w_slow + delta_slow;
            if (new_w_slow < 0) new_w_slow = 0;
            if (new_w_slow > 255) new_w_slow = 255;
            e->w_slow = new_w_slow;
        }
        
        // Credit accumulation
        if (surprise == 0 && U_ij > 0) {
            e->credit += 1;
        } else if (surprise == 1 && U_ij < 0) {
            e->credit -= 1;
        }
        
        if (e->credit > 10000) e->credit = 10000;
        if (e->credit < -10000) e->credit = -10000;
    }
    
    g_sys.mean_error = error_count > 0 ? total_error / error_count : 0.0f;
}

/* ========================================================================
 * PRUNING
 * ======================================================================== */

void prune() {
    // Prune weak edges
    for (uint32_t i = 0; i < g_graph.edge_count; i++) {
        int is_free = 0;
        for (uint32_t j = 0; j < g_graph.edge_free_count; j++) {
            if (g_graph.edge_free_list[j] == i) {
                is_free = 1;
                break;
            }
        }
        if (is_free) continue;
        
        Edge *e = &g_graph.edges[i];
        
        int w_eff = (int)(GAMMA_SLOW * e->w_slow + (1.0f - GAMMA_SLOW) * e->w_fast);
        
        if (w_eff < PRUNE_WEIGHT_THRESH && e->use_count < 10 && e->stale_ticks > STALE_THRESH) {
            edge_delete(&g_graph, i);
        }
    }
    
    // Prune isolated nodes
    for (uint32_t i = 0; i < g_graph.node_count; i++) {
        int is_free = 0;
        for (uint32_t j = 0; j < g_graph.node_free_count; j++) {
            if (g_graph.node_free_list[j] == i) {
                is_free = 1;
                break;
            }
        }
        if (is_free) continue;
        
        Node *n = &g_graph.nodes[i];
        
        if (n->in_deg == 0 && n->out_deg == 0) {
            if (g_sys.tick - n->last_tick_seen > NODE_STALE_THRESH) {
                node_delete(&g_graph, i);
                g_sys.nodes_pruned++;
            }
        }
    }
}

/* ========================================================================
 * NODE CREATION (Co-activation patterns)
 * ======================================================================== */

void try_create_nodes() {
    // Simple heuristic: find pairs of nodes that co-activate frequently
    // and have similar activation signatures
    
    for (uint32_t i = 0; i < g_graph.node_count && i < 1000; i++) {
        int is_free_i = 0;
        for (uint32_t j = 0; j < g_graph.node_free_count; j++) {
            if (g_graph.node_free_list[j] == i) {
                is_free_i = 1;
                break;
            }
        }
        if (is_free_i) continue;
        
        Node *ni = &g_graph.nodes[i];
        if (!ni->a) continue;
        
        for (uint32_t j = i + 1; j < g_graph.node_count && j < 1000; j++) {
            int is_free_j = 0;
            for (uint32_t k = 0; k < g_graph.node_free_count; k++) {
                if (g_graph.node_free_list[k] == j) {
                    is_free_j = 1;
                    break;
                }
            }
            if (is_free_j) continue;
            
            Node *nj = &g_graph.nodes[j];
            if (!nj->a) continue;
            
            // Check co-activation frequency
            uint32_t common_bits = ni->sig_history & nj->sig_history;
            uint32_t co_count = __builtin_popcount(common_bits);
            
            if (co_count < CO_FREQ_THRESH) continue;
            
            // Check similarity
            uint32_t xor_bits = ni->sig_history ^ nj->sig_history;
            float similarity = 1.0f - (__builtin_popcount(xor_bits) / 32.0f);
            
            if (similarity < SIM_THRESH) continue;
            
            // Create new internal node if no edge exists
            Edge *existing = find_edge(&g_graph, i, j);
            if (existing == NULL) {
                uint32_t new_idx = node_create(&g_graph);
                if (new_idx != UINT32_MAX) {
                    edge_create(&g_graph, i, new_idx);
                    edge_create(&g_graph, j, new_idx);
                    g_sys.nodes_created++;
                }
            }
        }
    }
}

/* ========================================================================
 * LAYER EMERGENCE (Meta-nodes from dense clusters)
 * ======================================================================== */

void try_layer_emergence() {
    // Simplified: find groups of highly connected nodes and create meta-node
    // In a full implementation, would use community detection algorithms
    
    // For now, just look for dense local neighborhoods
    for (uint32_t i = 0; i < g_graph.node_count && i < 500; i++) {
        int is_free = 0;
        for (uint32_t j = 0; j < g_graph.node_free_count; j++) {
            if (g_graph.node_free_list[j] == i) {
                is_free = 1;
                break;
            }
        }
        if (is_free) continue;
        
        Node *n = &g_graph.nodes[i];
        if (n->is_meta) continue;
        if (n->out_deg < LAYER_MIN_SIZE / 2) continue;
        
        // Count active neighbors
        uint32_t active_neighbors = 0;
        uint32_t total_neighbors = 0;
        
        for (uint32_t e = 0; e < g_graph.edge_count; e++) {
            int ef = 0;
            for (uint32_t k = 0; k < g_graph.edge_free_count; k++) {
                if (g_graph.edge_free_list[k] == e) {
                    ef = 1;
                    break;
                }
            }
            if (ef) continue;
            
            Edge *edge = &g_graph.edges[e];
            if (edge->src == i) {
                total_neighbors++;
                if (g_graph.nodes[edge->dst].a) {
                    active_neighbors++;
                }
            }
        }
        
        float density = total_neighbors > 0 ? (float)active_neighbors / total_neighbors : 0;
        
        if (density > DENSITY_THRESH && total_neighbors >= LAYER_MIN_SIZE) {
            uint32_t meta_idx = node_create(&g_graph);
            if (meta_idx != UINT32_MAX) {
                g_graph.nodes[meta_idx].is_meta = 1;
                g_graph.nodes[meta_idx].cluster_id = g_sys.layers_created;
                g_sys.layers_created++;
                
                // Connect meta-node to this node
                edge_create(&g_graph, i, meta_idx);
            }
        }
    }
}

/* ========================================================================
 * PERSISTENCE
 * ======================================================================== */

void persist_graph() {
    FILE *fn = fopen("nodes.bin", "wb");
    if (fn) {
        fwrite(&g_graph.node_count, sizeof(uint32_t), 1, fn);
        fwrite(&g_graph.next_node_id, sizeof(uint32_t), 1, fn);
        fwrite(g_graph.nodes, sizeof(Node), g_graph.node_count, fn);
        fclose(fn);
    }
    
    FILE *fe = fopen("edges.bin", "wb");
    if (fe) {
        fwrite(&g_graph.edge_count, sizeof(uint32_t), 1, fe);
        fwrite(g_graph.edges, sizeof(Edge), g_graph.edge_count, fe);
        fclose(fe);
    }
    
    printf("[PERSIST] tick=%llu nodes=%u edges=%u\n", 
           (unsigned long long)g_sys.tick, g_graph.node_count, g_graph.edge_count);
}

void restore_graph() {
    FILE *fn = fopen("nodes.bin", "rb");
    if (fn) {
        uint32_t count, next_id;
        fread(&count, sizeof(uint32_t), 1, fn);
        fread(&next_id, sizeof(uint32_t), 1, fn);
        
        if (count <= g_graph.node_cap) {
            fread(g_graph.nodes, sizeof(Node), count, fn);
            g_graph.node_count = count;
            g_graph.next_node_id = next_id;
            printf("[RESTORE] Loaded %u nodes\n", count);
        }
        fclose(fn);
    }
    
    FILE *fe = fopen("edges.bin", "rb");
    if (fe) {
        uint32_t count;
        fread(&count, sizeof(uint32_t), 1, fe);
        
        if (count <= g_graph.edge_cap) {
            fread(g_graph.edges, sizeof(Edge), count, fe);
            g_graph.edge_count = count;
            printf("[RESTORE] Loaded %u edges\n", count);
        }
        fclose(fe);
    }
}

/* ========================================================================
 * I/O
 * ======================================================================== */

void read_input() {
    // Non-blocking read from stdin
    uint8_t buf[1024];
    ssize_t n = read(STDIN_FILENO, buf, sizeof(buf));
    
    if (n > 0) {
        ring_write(&g_sys.rx_ring, buf, n);
    }
}

void slice_frame() {
    // Extract up to FRAME_SIZE bytes from RX ring for current tick
    g_sys.current_frame_len = ring_read(&g_sys.rx_ring, g_sys.current_frame, FRAME_SIZE);
}

void merge_output_into_input() {
    // Append last output to current input frame for self-observation
    if (g_sys.last_output_frame_len > 0 && 
        g_sys.current_frame_len + g_sys.last_output_frame_len < FRAME_SIZE) {
        
        memcpy(g_sys.current_frame + g_sys.current_frame_len,
               g_sys.last_output_frame,
               g_sys.last_output_frame_len);
        
        g_sys.current_frame_len += g_sys.last_output_frame_len;
    }
}

void emit_action() {
    uint32_t macro_idx = macro_select();
    Macro *m = &g_sys.macros[macro_idx];
    
    // Write to stdout
    write(STDOUT_FILENO, m->bytes, m->len);
    
    // Mirror to TX ring for self-observation
    ring_write(&g_sys.tx_ring, m->bytes, m->len);
    
    // Save as last output
    memcpy(g_sys.last_output_frame, m->bytes, m->len);
    g_sys.last_output_frame_len = m->len;
    
    // Update macro utility based on current error (simple reward signal)
    float reward = 1.0f - g_sys.mean_error;
    macro_update_utility(macro_idx, reward);
    
    // Decay epsilon
    g_sys.epsilon *= EPSILON_DECAY;
    if (g_sys.epsilon < EPSILON_MIN) g_sys.epsilon = EPSILON_MIN;
}

/* ========================================================================
 * MAIN LOOP
 * ======================================================================== */

void main_loop() {
    while (1) {
        // (1) INPUT — "what is happening?"
        read_input();
        slice_frame();
        
        // (2) RECALL LAST OUTPUT — "what did I do?"
        merge_output_into_input();
        
        // Run detectors to set sensory node activations
        detector_run_all(g_sys.current_frame, g_sys.current_frame_len);
        
        // (3) PREDICT — "what should happen?"
        propagate();
        observe_and_update();
        
        // Occasionally try to create new nodes from co-activation
        if (g_sys.tick % 10 == 0) {
            try_create_nodes();
        }
        
        // (4) OUTPUT — "do it"
        emit_action();
        
        // Housekeeping
        if (g_sys.tick % PRUNE_PERIOD == 0) {
            prune();
        }
        
        if (g_sys.tick % LAYER_PERIOD == 0) {
            try_layer_emergence();
        }
        
        if (g_sys.tick % SNAPSHOT_PERIOD == 0) {
            persist_graph();
        }
        
        // Logging
        if (g_sys.tick % 100 == 0) {
            printf("[TICK %llu] nodes=%u edges=%u active=%u err=%.3f created_e=%u pruned_e=%u created_n=%u layers=%u\n",
                   (unsigned long long)g_sys.tick,
                   g_graph.node_count,
                   g_graph.edge_count,
                   g_sys.active_node_count,
                   g_sys.mean_error,
                   g_sys.edges_created,
                   g_sys.edges_pruned,
                   g_sys.nodes_created,
                   g_sys.layers_created);
        }
        
        g_sys.tick++;
        
        // Sleep for tick duration
        usleep(TICK_MS * 1000);
    }
}

/* ========================================================================
 * INITIALIZATION
 * ======================================================================== */

void system_init(uint32_t node_cap, uint32_t edge_cap, uint32_t detector_cap, uint32_t macro_cap) {
    memset(&g_sys, 0, sizeof(System));
    
    graph_init(&g_graph, node_cap, edge_cap);
    
    ring_init(&g_sys.rx_ring, RX_RING_SIZE);
    ring_init(&g_sys.tx_ring, TX_RING_SIZE);
    
    detector_init(detector_cap);
    macro_init(macro_cap);
    
    g_sys.P1 = calloc(node_cap, sizeof(float));
    g_sys.P0 = calloc(node_cap, sizeof(float));
    
    // Initialize baseline to 0.5
    for (uint32_t i = 0; i < node_cap; i++) {
        g_sys.P1[i] = 0.5f;
        g_sys.P0[i] = 0.5f;
    }
    
    // Add default detectors
    detector_add("\n", 1);           // newline
    detector_add("/dev/video", 1);   // video device
    detector_add("error", 1);        // error string
    detector_add("Error", 1);
    detector_add("\xFF\xD8\xFF", 1); // JPEG header
    detector_add("created", 1);
    detector_add("success", 1);
    detector_add("failed", 1);
    detector_add("$", 1);            // shell prompt
    
    // Add default macros
    macro_add_defaults();
    
    printf("[INIT] System initialized: %u nodes, %u edges, %u detectors, %u macros\n",
           node_cap, edge_cap, g_sys.detector_count, g_sys.macro_count);
}

void system_cleanup() {
    graph_free(&g_graph);
    ring_free(&g_sys.rx_ring);
    ring_free(&g_sys.tx_ring);
    free(g_sys.detectors);
    free(g_sys.macros);
    free(g_sys.P1);
    free(g_sys.P0);
}

/* ========================================================================
 * MAIN
 * ======================================================================== */

int main(int argc, char **argv) {
    uint32_t node_cap = DEFAULT_NODE_CAP;
    uint32_t edge_cap = DEFAULT_EDGE_CAP;
    uint32_t detector_cap = DEFAULT_DETECTOR_CAP;
    uint32_t macro_cap = DEFAULT_MACRO_CAP;
    
    // Simple CLI parsing
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--nodes") == 0 && i + 1 < argc) {
            node_cap = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--edges") == 0 && i + 1 < argc) {
            edge_cap = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--help") == 0) {
            printf("Usage: %s [--nodes N] [--edges M]\n", argv[0]);
            printf("  --nodes N   Node capacity (default %u)\n", DEFAULT_NODE_CAP);
            printf("  --edges M   Edge capacity (default %u)\n", DEFAULT_EDGE_CAP);
            return 0;
        }
    }
    
    srand(time(NULL));
    
    // Set stdin to non-blocking
    int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);
    
    system_init(node_cap, edge_cap, detector_cap, macro_cap);
    
    // Try to restore previous state
    restore_graph();
    
    printf("=== MELVIN CORE STARTING ===\n");
    printf("Tick period: %d ms\n", TICK_MS);
    printf("Always-on loop active. Press Ctrl+C to stop.\n\n");
    
    main_loop();
    
    system_cleanup();
    
    return 0;
}

